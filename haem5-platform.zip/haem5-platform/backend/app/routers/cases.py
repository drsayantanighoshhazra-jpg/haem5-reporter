from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import audit
from ..crypto import dec_json, dec, enc
from ..db import get_db
from ..models import Case, Patient, User
from ..security import client_ip, need
from .patients import active_purposes

router = APIRouter(prefix="/api/cases", tags=["cases"])

# Fields from the workbench that identify a person — never stored inside case data (kept on Patient, encrypted).
STRIP = {"patient"}


class CaseIn(BaseModel):
    patient_id: str
    lab_no: str
    data: dict = {}


class CaseUpdate(BaseModel):
    data: dict
    diagnosis: str | None = None
    report: str | None = None
    ai_used: bool = False


def case_out(c: Case, p: Patient, full: bool) -> dict:
    out = {"id": c.id, "lab_no": c.lab_no, "patient_id": p.id, "pseudonym": p.pseudonym, "diagnosis": c.diagnosis,
           "status": c.status, "ai_used": c.ai_used, "updated_at": c.updated_at, "signed_at": c.signed_at,
           "permissions": {"ai_allowed": "ai_assisted_analysis" in active_purposes(p),
                           "processing_allowed": "diagnostic_reporting" in active_purposes(p) and not p.erased_at}}
    if full:
        out["data"] = dec_json(c.data_enc) or {}
        out["report"] = dec(c.report_enc)
    return out


def _consent_gate(p: Patient):
    if p.erased_at:
        raise HTTPException(410, "This patient's personal data has been erased")
    if "diagnostic_reporting" not in active_purposes(p):
        raise HTTPException(409, "Consent for diagnostic reporting has been withdrawn — processing must stop")


@router.post("")
def create_case(body: CaseIn, request: Request, u: User = Depends(need("cases.write")), db: Session = Depends(get_db)):
    p = db.get(Patient, body.patient_id)
    if not p:
        raise HTTPException(404, "Patient not found")
    _consent_gate(p)
    data = {k: v for k, v in body.data.items() if k not in STRIP}
    c = Case(patient_id=p.id, lab_no=body.lab_no.strip(), data_enc=enc(data), created_by=u.id)
    db.add(c); db.commit()
    audit.log(db, u.id, "case.created", "case", c.id, {"patient": p.pseudonym, "lab_no": c.lab_no}, client_ip(request))
    return case_out(c, p, True)


@router.get("")
def list_cases(u: User = Depends(need("cases.read")), db: Session = Depends(get_db)):
    rows = db.execute(select(Case, Patient).join(Patient).order_by(Case.updated_at.desc()).limit(500)).all()
    return [case_out(c, p, False) for c, p in rows]


@router.get("/{cid}")
def get_case(cid: str, request: Request, u: User = Depends(need("cases.read")), db: Session = Depends(get_db)):
    c = db.get(Case, cid)
    if not c:
        raise HTTPException(404, "Case not found")
    p = db.get(Patient, c.patient_id)
    audit.log(db, u.id, "case.viewed", "case", c.id, {"patient": p.pseudonym}, client_ip(request))
    return case_out(c, p, True)


@router.put("/{cid}")
def update_case(cid: str, body: CaseUpdate, request: Request, u: User = Depends(need("cases.write")), db: Session = Depends(get_db)):
    c = db.get(Case, cid)
    if not c:
        raise HTTPException(404, "Case not found")
    if c.status == "signed":
        raise HTTPException(409, "Signed reports are locked. Issue an addendum instead.")
    p = db.get(Patient, c.patient_id)
    _consent_gate(p)
    if body.ai_used and "ai_assisted_analysis" not in active_purposes(p):
        raise HTTPException(409, "No consent for AI-assisted analysis — count manually")
    c.data_enc = enc({k: v for k, v in body.data.items() if k not in STRIP})
    c.diagnosis = (body.diagnosis or "")[:300] or None
    c.report_enc = enc(body.report)
    c.ai_used = c.ai_used or body.ai_used
    db.commit()
    audit.log(db, u.id, "case.updated", "case", c.id, {"ai_used": body.ai_used}, client_ip(request))
    return case_out(c, p, True)


@router.post("/{cid}/sign")
def sign_case(cid: str, request: Request, u: User = Depends(need("cases.sign")), db: Session = Depends(get_db)):
    c = db.get(Case, cid)
    if not c:
        raise HTTPException(404, "Case not found")
    p = db.get(Patient, c.patient_id)
    _consent_gate(p)
    if not c.diagnosis or not c.report_enc:
        raise HTTPException(400, "Add a diagnosis and report before signing")
    c.status = "signed"; c.signed_by = u.id; c.signed_at = datetime.now(timezone.utc)
    db.commit()
    audit.log(db, u.id, "case.signed", "case", c.id, {"patient": p.pseudonym}, client_ip(request))
    return case_out(c, p, True)
