"""Runtime configuration. Every secret comes from the environment; nothing sensitive is hard-coded."""
import base64
import os
from dataclasses import dataclass, field


def _env(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)


@dataclass
class Settings:
    # --- storage ---
    db_url: str = field(default_factory=lambda: _env("HAEM5_DB_URL", "sqlite:///./haem5.db"))
    # 32-byte AES-256 key (base64) for field-level encryption of identifiers and clinical text.
    data_key_b64: str | None = field(default_factory=lambda: _env("HAEM5_DATA_KEY"))
    jwt_secret: str | None = field(default_factory=lambda: _env("HAEM5_JWT_SECRET"))
    token_minutes: int = field(default_factory=lambda: int(_env("HAEM5_TOKEN_MINUTES", "30")))

    # --- DPDP: data fiduciary & contact (Rule 9 — published contact for Data Principals) ---
    fiduciary_name: str = field(default_factory=lambda: _env("HAEM5_FIDUCIARY", "Department of Pathology (demo institution)"))
    dpo_name: str = field(default_factory=lambda: _env("HAEM5_DPO_NAME", "Data Protection Officer"))
    dpo_email: str = field(default_factory=lambda: _env("HAEM5_DPO_EMAIL", "dpo@example.org"))
    dpo_phone: str = field(default_factory=lambda: _env("HAEM5_DPO_PHONE", "+91-00000-00000"))
    data_region: str = field(default_factory=lambda: _env("HAEM5_DATA_REGION", "India (ap-south-1)"))

    # --- retention (Act s.8(7); Rules 6 & 8) ---
    record_retention_years: int = field(default_factory=lambda: int(_env("HAEM5_RECORD_RETENTION_YEARS", "5")))
    log_retention_days: int = field(default_factory=lambda: max(365, int(_env("HAEM5_LOG_RETENTION_DAYS", "365"))))
    erasure_notice_hours: int = 48
    rights_sla_days: int = 90          # Rule 14: grievances within 90 days; used for all rights requests
    breach_board_hours: int = 72       # Rule 7: detailed intimation to the Board within 72 hours

    # --- security ---
    require_2fa: bool = field(default_factory=lambda: _env("HAEM5_REQUIRE_2FA", "true").lower() == "true")
    max_failed_logins: int = 5
    lockout_minutes: int = 15
    cors_origins: list[str] = field(default_factory=lambda: [o for o in (_env("HAEM5_CORS", "") or "").split(",") if o])
    demo_mode: bool = field(default_factory=lambda: _env("HAEM5_DEMO", "false").lower() == "true")

    @property
    def data_key(self) -> bytes:
        if not self.data_key_b64:
            raise RuntimeError("HAEM5_DATA_KEY is not set (base64-encoded 32-byte key). See docs/DEPLOY.md.")
        k = base64.b64decode(self.data_key_b64)
        if len(k) != 32:
            raise RuntimeError("HAEM5_DATA_KEY must decode to exactly 32 bytes.")
        return k

    def validate(self) -> None:
        _ = self.data_key
        if not self.jwt_secret or len(self.jwt_secret) < 32:
            raise RuntimeError("HAEM5_JWT_SECRET must be set to at least 32 characters.")


settings = Settings()
