/* Connects the WHO-HAEM5 workbench to the platform API.
   Loaded after the workbench script: uses its globals (state, loadCase, buildReport, renderForms, show, toast). */
(function () {
  "use strict";
  const token = sessionStorage.getItem("haem5.t");
  const caseId = new URLSearchParams(location.search).get("case");
  const api = async (path, opts = {}) => {
    const r = await fetch(path, { ...opts, headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: opts.body ? JSON.stringify(opts.body) : undefined });
    const d = await r.json().catch(() => ({}));
    if (r.status === 401) { location.href = "/"; throw new Error("Signed out"); }
    if (!r.ok) throw new Error(Array.isArray(d.detail) ? d.detail.map(x => x.msg).join("; ") : d.detail || "Request failed");
    return d;
  };
  if (!token || !caseId) { location.href = "/"; return; }

  const hdr = document.querySelector("header.top .wrap");
  document.getElementById("exampleSel").hidden = true;
  document.getElementById("newWrap").hidden = true;
  const info = el("span", { class: "hint", id: "srvInfo" }, "Loading case…");
  const save = el("button", { class: "btn sm", id: "srvSave" }, "Save draft");
  const sign = el("button", { class: "btn sm", id: "srvSign" }, "Sign report");
  const back = el("a", { class: "btn sm ghost", href: "/#cases" }, "← Cases");
  hdr.insertBefore(back, hdr.firstChild);
  hdr.append(info, save, sign);

  let meta = null;
  function lockIfSigned() {
    const signed = meta.status === "signed";
    save.disabled = sign.disabled = signed || !meta.permissions.processing_allowed;
    info.textContent = `${meta.lab_no} · ${meta.pseudonym} · ${signed ? "signed " + new Date(meta.signed_at).toLocaleString("en-IN") : "draft"}` +
      (meta.permissions.processing_allowed ? "" : " · consent withdrawn — read only") + (meta.permissions.ai_allowed ? " · AI consented" : " · no AI consent");
  }
  async function load() {
    try {
      meta = await api(`/api/cases/${caseId}`);
      window.HAEM5_AI_ALLOWED = !!meta.permissions.ai_allowed;
      loadCase(Object.assign({ labNo: meta.lab_no, patient: meta.pseudonym }, meta.data || {}), false);
      lockIfSigned();
    } catch (e) { info.textContent = e.message; }
  }
  async function persist() {
    const rt = document.getElementById("reportText");
    const report = rt && rt.value ? rt.value : buildReport();
    const data = Object.assign({}, state); delete data.patient;
    meta = await api(`/api/cases/${caseId}`, { method: "PUT", body: { data, diagnosis: state.dx || null, report, ai_used: !!state.aiUsed } });
    lockIfSigned();
  }
  save.onclick = async () => { try { await persist(); toast("Draft saved"); } catch (e) { toast(e.message); } };
  sign.onclick = () => {
    const box = el("span", { class: "confirm" }, "Sign and lock this report?",
      el("button", { class: "btn sm primary", onclick: async () => { try { await persist(); meta = await api(`/api/cases/${caseId}/sign`, { method: "POST" }); lockIfSigned(); toast("Report signed"); } catch (e) { toast(e.message); } box.remove(); sign.hidden = false; } }, "Sign"),
      el("button", { class: "btn sm ghost", onclick: () => { box.remove(); sign.hidden = false; } }, "Cancel"));
    sign.hidden = true; sign.after(box);
  };
  load();
})();
