"""Builds frontend/workbench.html (server mode) and the standalone demo page from the shared sources."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "frontend"
tpl = (ROOT / "src/workbench_template.html").read_text()
engine = (ROOT / "src/haem5_engine.js").read_text()
detector = (ROOT / "src/cell_detect.js").read_text()
body = tpl.replace("/*__ENGINE__*/", engine + "\n" + detector)

head = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>')
flags = ('<script>window.HAEM5_NO_LOCAL = true; window.HAEM5_WASM_URL = "/static/ort-wasm-simd-threaded.wasm";</script>')
first_script = body.index("<script")
server = head + body[:first_script] + flags + body[first_script:] + '<script src="/static/workbench_bridge.js"></script></body></html>'
(ROOT / "workbench.html").write_text(server)
(ROOT / "standalone_demo.html").write_text(body)
print("built", len(server) // 1024, "KB")

# Published showcase = standalone workbench + DPDP showcase layer
sc = (ROOT / "src/showcase.js").read_text()
i = body.rindex("</script>") + len("</script>")
(ROOT / "showcase.html").write_text(body[:i] + "\n<script>\n" + sc + "\n</script>\n" + body[i:])
print("built showcase")
